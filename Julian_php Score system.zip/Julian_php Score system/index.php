<?php include "pubs.php";?>
<!doctype html><?php $tts = date("YmdHis",time());?>
<html lang="zh-CN">
<?php

error_reporting(0);
header("content-Type: text/html; charset=utf-8");
$title="Score report system";		
$copyr="RDFZ-ICC";		
$tiaojian1="ID";		

$dbtype =".php"; 		
$UpDir="score"; 	 
$copyu="/";			
?>
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width,minimum-scale=1.0,maximum-scale=1.0" />
<meta name="apple-mobile-web-app-capable" content="yes" />
<title><?php echo $title;?></title>
<link href="style.css?v=V191022_0223153Y2&t=170828" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="js.js?v=V191022_0223153Y2&t=170828"></script>
</head>
<body onLoad="inst();">
<div class="html">
<div class="divs" id="divs">
<div id="head" class="head" onclick="location.href='?t=<?php echo $tts;?>';">
<?php echo $title;?>
<!--div class="back" id="pageback">
<a href="?t=<?php echo $tts;?>" class="d">更多</a>
</div-->
</div>
<div class="main" id="main">
<?php
$stime=microtime(true);
$codes = trim($_POST['code']);
$shujus = trim($_POST['time']);
$shuru1 = trim($_POST['name']);
if(!$shujus){

 //index.php?t=191022@5dadf79361558&m=11c70f2ec66f004bd878dcedec867af2 
?>
<form name="queryForm" method="post" action="?t=<?php echo $tts;?>" onsubmit="return Check3Y2(0);">
<div class="select" id="10">
<select name="time" id="time" onBlur="Check3Y2(1)" >
<?php traverse($UpDir."/",$dbtype);?></select></div>
<div class="so_box" id="11">
<input name="name" type="text" class="txts" id="name" value="" placeholder="Input <?php echo $tiaojian1;?> like 900000002" onfocus="st('name',1)" onBlur="Check3Y2(2)" />
</div>
<div class="so_but">
<input type="submit" name="button" class="buts" id="sub" value="Search" />
<input type="button" class="buts" value="Refresh" name="print" onclick="location.reload();">
</div>
</form>
<?php
}else{
if(!$shuru1){
webalert("Input$tiaojian1!");
}
$files = $UpDir."/".$shujus.$dbtype;
$files = charaget($files);
if(!file_exists($files)){
$files = characet($files);
}
if(!file_exists($files)){
webalert('Check your files');
}
echo '<p align="center">&nbsp;</p>';
echo '<p align="center"> ' . rephtmls(Trim($shujus)) . '</p>';
echo "<!--startprint-->";
$filer = fopen($files, "r") or  webalert('Unable to open!');
$ii = "0";
while(!feof($filer)){
$ii++;
$rows=fgets($filer);
if($rows){
if($ii."_"=="1_"){
//echo "<caption align=\"center\"> Results</caption><thead>";
echo "<table cellspacing=\"0\"><thead>";
}elseif($ii."_"=="2_"){
$lineone=$rows;
$tabv=explode("\t",$rows);
$io=0;
$iaa=-1;
echo '<tr class="tt">';
foreach($tabv as $tabu){
$io++;
$bh0=stristr($bubuxians,"--$tabu--");
if(!$bh0){
echo '<td>'.$tabu.'</td>';
}
if($tabu==$tiaojian1){
$iaa=$io-1;
}
}
echo "</tr></thead><tbody>";
if(strlen($iaa)<0){   //if($iaa){
webalert('Check if【'.$tiaojian1.'】exist!');
}
}else{
$tabvt=explode("\t",$lineone);
$tabvs=explode("\t",$rows);
$lia1 = Tram($tabvs[$iaa]);
if("_".$shuru1=="_".$lia1){
$iae++;
$iaf=0;
echo '<tr>';
foreach($tabvs as $tabu){
$iaf++;
$iag=$iaf-1;
$line1tou =$tabvt["$iag"];
echo '<td data-label='.$line1tou.'>'.$tabu.'</td>';
}
echo '</tr>';
}
}
}
}
if($iae<1){
$shuru1 = rephtmls($shuru1);
$shuru2 = rephtmls($shuru2);
echo '<tr>';
echo "<td colspan=$io  data-label=\"Tip \">There is no information for $tiaojian1 = $shuru1 </td>";
echo '</tr>';
}
echo '<tbody></table>';
echo '<!--endprint-->';
//fclose($filer);
?>
<div class="so_but">
<input type="button" class="buts" value="Print preview" name="print" onclick="preview()">
<input type="button" class="buts" value="Back" id="reset" onclick="location.href='?t=back';"></div>
<?php
}
$etime=microtime(true);
$total=$etime-$stime;
echo "<!----页面执行时间：{$total} ]秒--->";
?>
</div>
<div class="boto" id="boto">
&copy;<?php echo date('Y');?>&nbsp; <a href="<?php echo $copyu;?>" target="_blank"><?php echo $copyr;?></a>
</div>
</div>
</div>
</body>
</html>